package com.smali.secretchallenge;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pore.mylibrary.PoRELab;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MainActivity extends AppCompatActivity {
    private Button button = null;
    private EditText input_edit = null;
    public TextView tv = null;
    private  String FILENAME = "hello_file";
    private String[] permissions ={
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input_edit = (EditText) findViewById(R.id.editText1);
        button = (Button) findViewById(R.id.button1);

        //This is the text that showed in the MainActivity.
        tv = (TextView) findViewById(R.id.text);

        //Save the file in the internal storage.
        final String string = "Hello hacker!";
        try {
            FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
            fos.write(string.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Task 1 TODO: How to dynamic request some sensitive permission? And how to monitor the BOOT_COMPLETED action to start a secret service to toast?
        if (ContextCompat.checkSelfPermission(this, permissions[0]) != PackageManager.PERMISSION_GRANTED
            ||ContextCompat.checkSelfPermission(this, permissions[1]) != PackageManager.PERMISSION_GRANTED)
        {//如果表中权限没有被授权，就动态申请
            ActivityCompat.requestPermissions(this, permissions, 100);
        }
        Intent intent = new Intent(MainActivity.this, SecretService.class);
        startService(intent);

        button.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //This is the String you get from the EditText view.
                final String input = input_edit.getText().toString();

                //Task 2 TODO:How to read a file from the internal storage? And how to change the text that showed in the MainActivity?
                StringBuffer stringBuffer = new StringBuffer();
                byte[] buffer = new byte[1024];
                try {
                    FileInputStream fin = new FileInputStream(getFilesDir().getAbsolutePath() + File.separator + FILENAME);
                    Log.i("mTest","open^^^");
                    int len = fin.read(buffer);
                    while (len > 0) {
                        Log.i("mTest","while len>0");
                        Log.i("mTest",buffer.toString());
                        stringBuffer.append(new String(buffer, 0, len));
                        // 继续将数据放到buffer中
                        Log.i("mTest",stringBuffer.toString());
                        len = fin.read(buffer);
                    }
                    fin.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.i("mTest","exception");
                }
                tv.setText(stringBuffer.toString());


                //The App will crash if you click the button. So edit this class.
                // Task 3 TODO: In child thread how to make Dialog in main thread?
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // Make a dialog rather than edit the text in main UI
                        Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {
                            @Override
                            public void run(){
                                new AlertDialog.Builder(MainActivity.this).setMessage(input).setPositiveButton("ok", null).show();
                            }
                        });
                    }
                }).start();

                // Task 4 TODO: How to get the private variable of PoRELab class? And How to invoke the private method?
                PoRELab.publicMethod(input);
                try {
                    Class c = Class.forName("com.pore.mylibrary.PoRELab");
                    Method method = c.getDeclaredMethod("privateMethod", String.class, String.class);
                    method.setAccessible(true);
                    Field tag = c.getDeclaredField("curStr");
                    tag.setAccessible(true);
                    Object obj = c.newInstance();
                    method.invoke(obj, "hello", tag.get(obj));
                } catch (ClassNotFoundException | NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (NoSuchFieldException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
