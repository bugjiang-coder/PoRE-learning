package com.smali.secretchallenge;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.pore.mylibrary.PoRELab;

import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private Button button = null;
    private EditText input_edit = null;
    public TextView tv = null;
    private  String FILENAME = "hello_file";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input_edit = (EditText) findViewById(R.id.editText1);
        button = (Button) findViewById(R.id.button1);

        //This is the text that showed in the MainActivity.
        tv = (TextView) findViewById(R.id.text);

        //Save the file in the internal storage.
        String string = "Hello hacker!";
        try {
            FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
            fos.write(string.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Task 1 TODO: How to dynamic request some sensitive permission? And how to monitor the BOOT_COMPLETED action to start a secret service to toast?


        button.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //This is the String you get from the EditText view.
                final String input = input_edit.getText().toString();
                //Task 2 TODO:How to read a file from the internal storage? And how to change the text that showed in the MainActivity?

                //The App will crash if you click the button. So edit this class.
                // Task 3 TODO: In child thread how to make Dialog in main thread?
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // Make a dialog rather than edit the text in main UI
                        tv.setText(input);
                    }
                }).start();

                // Task 4 TODO: How to get the private variable of PoRELab class? And How to invoke the private method?
                PoRELab.publicMethod(input);
            }
        });
    }
}
