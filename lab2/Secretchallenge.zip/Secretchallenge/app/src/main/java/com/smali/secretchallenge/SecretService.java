package com.smali.secretchallenge;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

public class SecretService extends Service {
    private LocationManager locationManager;
    private Location location;
    public static final int UPDATE_UI = 1;

    public SecretService() {
    }

    @Override
    public void onCreate() {
        startCheckingPosition();
        Log.i("mTest","SecretService is onCreate");
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("mTest","SecretService is working");
        new Thread(new Runnable() {
            @Override
            public void run() {
//新开一个线程来处理位置的toast，Android中的UI是线程不安全的，因此要更新UI必须在主线程中进行,所以必须使用Handler处理
                while (true) {
                    try {
                        Message message= new Message();
                        message.what = UPDATE_UI;
                        handler.sendMessage(message);
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    public void startCheckingPosition() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;//未获得权限直接返回
        }
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1,
                new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {

                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {

                    }

                    @Override
                    public void onProviderEnabled(String provider) {

                    }

                    @Override
                    public void onProviderDisabled(String provider) {

                    }
                });
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }

    Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            if(msg.what==UPDATE_UI){
                if (location != null) {
                    final String postString = "Location:\n" +
                            "Longitude:" +
                            location.getLongitude() +
                            "\n" +
                            "Latitude:" +
                            location.getLatitude();

                    Toast.makeText(getApplicationContext(), postString, Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getApplicationContext(), "No GPS Signal", Toast.LENGTH_SHORT).show();
                }

            }
        }
    };



}