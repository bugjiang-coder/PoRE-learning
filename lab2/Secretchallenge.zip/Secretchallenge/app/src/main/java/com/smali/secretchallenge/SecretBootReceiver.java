package com.smali.secretchallenge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class SecretBootReceiver extends BroadcastReceiver {
    static final String ACTION = "android.intent.action.BOOT_COMPLETED";
    @Override
    public void onReceive(Context context, Intent intent){
        if (intent.getAction().equals(ACTION)){
//            Intent service = new Intent(context, SecretService.class);
//            service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startService(service);
            Log.i("mTest","receiver is working");
            Intent intent1 = new Intent(context, MainActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent1);
        }
    }

}
